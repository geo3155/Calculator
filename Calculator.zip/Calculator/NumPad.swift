//
//  NumPad.swift
//  Calculator
//
//  Created by George Predan on 02.03.2024.
//

import SwiftUI

struct NumPad: View {
    var numbers: [[String]]
    let action: (String) -> Void
    var body: some View {
        ForEach(numbers, id: \.self) { row in
            HStack(spacing: 20) {
                ForEach(row, id: \.self) { num in
                    DigitButton(digit: num) {
                        action(num)
                    }
                }
            }
        }
    }
}

#Preview {
    NumPad(numbers: [[""]], action: {_ in})
}
