//
//  DigitButton.swift
//  Calculator
//
//  Created by George Predan on 02.03.2024.
//

import SwiftUI

struct DigitButton: View {
    
    var digit: String = ""
    var backgroundColor: Color = .indigo
    var action: () -> Void = {}
    
    var body: some View {
        Button {
            action()
        } label: {
            RoundedRectangle(cornerRadius: 15)
                .fill(backgroundColor)
                .frame(width: 70, height: 70)
                .overlay {
                    Text(digit)
                        .font(.largeTitle)
                        .bold()
                        .foregroundStyle(.white)
                }
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    DigitButton(digit: "3")
}
