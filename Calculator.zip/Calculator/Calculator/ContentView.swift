//
//  ContentView.swift
//  Calculator
//
//  Created by George Predan on 02.03.2024.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = CalculatorViewModel()
    
    var body: some View {
        VStack(spacing: 20) {
            HStack {
                Text(viewModel.currentOperator?.rawValue ?? "")
                    .font(.largeTitle)
                    .foregroundStyle(.blue)
                Spacer()
                DigitButton(digit: "C", backgroundColor: .black) {
                    viewModel.resetC()
                }
            }
            .padding()
            Spacer()
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
//                    Text(viewModel.resultStatement ?
//                         Int(Double(viewModel.currentValue) ?? 0).description :
//                            viewModel.currentValue)
                    Text(viewModel.currentValue)
                        .font(.largeTitle)
                        .bold()
                        .lineLimit(1)
                }
                .padding(.horizontal)
            }
            Divider()
            NumPad(numbers: viewModel.numbers) { num in
                viewModel.numPadLogic(num)
            }
        }
        .background {
            Color.black.opacity(0.2)
                .ignoresSafeArea()
        }
    }
}

#Preview {
    ContentView()
}
