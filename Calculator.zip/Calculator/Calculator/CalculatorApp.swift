//
//  CalculatorApp.swift
//  Calculator
//
//  Created by George Predan on 02.03.2024.
//

import SwiftUI

@main
struct CalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
