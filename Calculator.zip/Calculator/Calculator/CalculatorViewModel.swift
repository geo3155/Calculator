//
//  CalculatorViewModel.swift
//  Calculator
//
//  Created by George Predan on 02.03.2024.
//

import Foundation

class CalculatorViewModel: ObservableObject {
    @Published var firstNum: Double = 0
    @Published var secondNum: Double = 0
    @Published var currentValue: String = "0"
    @Published var currentResult: Double = 0
    @Published var currentOperator: Operators?
    @Published var firstValue = true
    var isDouble = false
    var isNegative = false
//    var resultStatement: Bool {
//        return Double(currentValue)?.isInteger ?? false
//    }
    
    let numbers = [["7", "8", "9", "÷"],
                   ["4", "5", "6", "x"],
                   ["1", "2", "3", "-"],
                   ["0", ".", "=", "+"]]
    
    func numPadLogic(_ num: String) {
        if Int(num) != nil {
            addDigit(num)
        } else if num == "." {
            if !isDouble {
                addDigit(num)
            }
        } else {
            if currentOperator != nil && !isNegative && num == "-" {
                addDigit(num)
                isNegative = true
            } else {
                selectOperator(num)
            }
        }
    }
    
    func addDigit(_ digit: String) {
        if digit == "." {
            if firstValue == true {
                currentValue = "0."
            }
            else {
                currentValue += digit
            }
            isDouble = true
            firstValue = false
            return
        }
        if currentValue.first == "0" && !isDouble {
            firstValue = true
            if digit == "0" {
                return
            }
        }
        if firstValue {
            currentValue = digit
            firstValue = false
        }
        else {
            currentValue += digit
            print("A intrat \(digit)")
        }
        
    }
    
    func selectOperator(_ digit: String) {
        
        if let num = Double(currentValue) {
            if firstNum != 0 && secondNum != 0 {
                return
            }
            else if firstNum != 0 {
                secondNum = num
            }
            else {
                firstNum = num
            }
        }
        
        firstValue = true
        isDouble = false
        isNegative = false
        
        switch digit {
        case "÷":
            currentOperator = .divide
        case "x":
            currentOperator = .multiplication
        case "-":
            currentOperator = .substraction
        case "+":
            currentOperator = .addition
        case "=":
            modifyResult()
            equalReset()
        default:
            return
        }
    }
    
    func modifyResult() {
        
        //        print(secondNum.description)
        //        print(currentOperator?.rawValue)
        
        switch currentOperator {
        case .addition:
            currentResult = firstNum + secondNum
            print("Sal")
        case .substraction:
            currentResult = firstNum - secondNum
        case .divide:
            currentResult = firstNum / secondNum
        case .multiplication:
            currentResult = firstNum * secondNum
        case nil:
            return
        }
        
        currentValue = currentResult.description
    }
    
    func resetC() {
        currentValue = "0"
        currentResult = 0
        firstValue = true
        isDouble = false
        isNegative = false
    }
    
    func equalReset() {
        currentOperator = nil
        firstNum = 0
        secondNum = 0
        firstValue = true
        isDouble = false
        isNegative = false
    }
}

enum Operators: String {
    case addition, substraction, divide, multiplication
}


extension FloatingPoint {
    var isInteger: Bool {
        rounded() == self
    }
}
